# 🔑 Using Your Polymarket Builder API Key

## Why Use API Key?

✅ **Higher rate limits** - Make more requests per minute
✅ **Better reliability** - Less likely to hit rate limits
✅ **Access to more data** - Some endpoints require authentication
✅ **Faster scanning** - Can query more markets simultaneously

---

## How to Get Your Builder API Key

### Step 1: Access Polymarket Builder Dashboard

1. Go to [https://polymarket.com](https://polymarket.com)
2. Connect your wallet
3. Navigate to "Builder" or "API" section in settings
4. Or directly visit the Builder portal

### Step 2: Generate API Key

1. Look for "API Keys" or "Developer Access"
2. Click "Generate New API Key" or similar
3. **Save this key securely** - you won't see it again!
4. Copy the key (format: `poly_xxxxxxxxxxxxxxxxxxxxxx`)

### Step 3: Add to Dashboard

1. Open the Streamlit dashboard
2. In sidebar, check "Use API Key (Recommended)"
3. Paste your API key in the password field
4. Click "🔄 Initialize Monitor"
5. You should see "✅ API key configured"

---

## Using API Key in Dashboard

### In the Sidebar:

```
🔑 Polymarket API
☑️ Use API Key (Recommended)
[Enter your API key here - it's hidden]
```

**After entering:**
- ✅ Green checkmark = Key configured
- 🚀 Message on init = "Using authenticated API"

---

## Using API Key Programmatically

```python
from polymarket_monitor import PolymarketMonitor

# Initialize with API key
monitor = PolymarketMonitor(
    api_key="poly_your_api_key_here"
)

# Run scans with better rate limits
monitor.scan_markets()
```

---

## Benefits with API Key

### Without API Key (Public):
- ⚠️ ~60 requests per minute
- ⚠️ May get rate limited during heavy scans
- ⚠️ Slower data collection

### With API Key (Authenticated):
- ✅ Higher rate limits (hundreds per minute)
- ✅ No rate limit issues
- ✅ Faster comprehensive scans
- ✅ Better for continuous monitoring

---

## Security Best Practices

### ✅ DO:
- Keep your API key secret
- Store it in environment variables for production
- Use dashboard's password field (hidden input)
- Rotate keys periodically

### ❌ DON'T:
- Share your API key publicly
- Commit it to GitHub
- Post it in screenshots
- Use same key across multiple apps

---

## Troubleshooting

### "Invalid API Key" Error
- Check you copied the full key
- Ensure no extra spaces
- Verify key hasn't been revoked
- Generate a new key if needed

### Still Getting Rate Limited?
- You might be scanning too fast
- Increase delay between requests
- Contact Polymarket support for higher limits

### API Key Not Working?
- Make sure you checked the "Use API Key" checkbox
- Re-initialize the monitor after entering key
- Check Polymarket Builder dashboard for key status

---

## Production Setup

### Environment Variable Method:

1. Create `.env` file:
```bash
POLYMARKET_API_KEY=poly_your_key_here
```

2. Update code to load from env:
```python
import os
from dotenv import load_dotenv

load_dotenv()

monitor = PolymarketMonitor(
    api_key=os.getenv("POLYMARKET_API_KEY")
)
```

3. Install python-dotenv:
```bash
pip install python-dotenv
```

---

## For Streamlit Cloud Deployment

### Add API Key as Secret:

1. Go to your Streamlit Cloud app
2. Settings → Secrets
3. Add:
```toml
POLYMARKET_API_KEY = "poly_your_key_here"
```

4. Update dashboard.py to read from secrets:
```python
import streamlit as st

# In sidebar
if api_key_enabled:
    api_key = st.secrets.get("POLYMARKET_API_KEY", "")
    if not api_key:
        api_key = st.text_input("Builder API Key", type="password")
```

---

## Rate Limits Reference

### Public API (No Key):
- Markets: ~60 req/min
- Trades: ~60 req/min
- Prices: ~60 req/min

### Builder API (With Key):
- Markets: ~300+ req/min
- Trades: ~300+ req/min
- Prices: ~300+ req/min
- Plus access to additional endpoints

*Note: Exact limits may vary - check Polymarket documentation*

---

## FAQ

**Q: Do I need an API key?**
A: No, but highly recommended for better performance

**Q: Is it free?**
A: Yes, Builder API keys are free

**Q: Can I use multiple keys?**
A: Yes, but one per monitor instance

**Q: Will it work without a key?**
A: Yes, just with lower rate limits

**Q: How often should I rotate keys?**
A: Every 3-6 months, or if compromised

---

## Summary

1. ✅ Get your key from Polymarket Builder dashboard
2. ✅ Add it to the Streamlit sidebar (password field)
3. ✅ Check "Use API Key" checkbox
4. ✅ Initialize monitor
5. ✅ Enjoy faster, more reliable scanning!

**Your monitoring will be significantly better with the API key!** 🚀
